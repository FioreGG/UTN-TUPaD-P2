/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp8_p1;

public class TarjetaCredito implements PagoConDescuento {

    @Override
    public void procesarPago(double monto) {
        System.out.println("Procesando pago con tarjeta por $" + monto);
    }
   
    @Override
    public double aplicarDescuento (double porcentaje) {
        System.out.println("Aplicando descuento de " + porcentaje + "%");
    return porcentaje;    }
   
}
