/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp6;


public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        // 1. Crear productos
        Producto p1 = new Producto("P01", "Pan", 800, 20, CategoriaProducto.ALIMENTOS);
        Producto p2 = new Producto("P02", "Televisor", 250000, 5, CategoriaProducto.ELECTRONICA);
        Producto p3 = new Producto("P03", "Remera", 3500, 12, CategoriaProducto.ROPA);
        Producto p4 = new Producto("P04", "Silla", 9000, 7, CategoriaProducto.HOGAR);
        Producto p5 = new Producto("P05", "Yerba", 1500, 30, CategoriaProducto.ALIMENTOS);

        inventario.agregarProducto(p1);
        inventario.agregarProducto(p2);
        inventario.agregarProducto(p3);
        inventario.agregarProducto(p4);
        inventario.agregarProducto(p5);

        System.out.println("\n📦 LISTADO DE PRODUCTOS:");
        inventario.listarProductos();

        System.out.println("\n🔍 BUSCAR PRODUCTO POR ID (P03):");
        Producto buscado = inventario.buscarProductoPorId("P03");
        if (buscado != null) buscado.mostrarInfo();

        System.out.println("\n📂 FILTRAR POR CATEGORIA ALIMENTOS:");
        inventario.filtrarPorCategoria(CategoriaProducto.ALIMENTOS);

        System.out.println("\n❌ ELIMINAR PRODUCTO P02:");
        inventario.eliminarProducto("P02");
        inventario.listarProductos();

        System.out.println("\n♻️ ACTUALIZAR STOCK DE P01:");
        inventario.actualizarStock("P01", 50);

        System.out.println("\n📊 TOTAL DE STOCK DISPONIBLE: " + inventario.obtenerTotalStock());

        System.out.println("\n🏆 PRODUCTO CON MAYOR STOCK:");
        Producto mayor = inventario.obtenerProductoConMayorStock();
        if (mayor != null) mayor.mostrarInfo();

        System.out.println("\n💰 PRODUCTOS CON PRECIO ENTRE $1000 Y $3000:");
        inventario.filtrarProductosPorPrecio(1000, 3000);

        System.out.println("\n📚 CATEGORIAS DISPONIBLES:");
        inventario.mostrarCategoriasDisponibles();
    }
}
  