/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp6_b;

public class TP6_b {

    public static void main(String[] args) {
        
    // 1. Crear biblioteca
        Biblioteca biblioteca = new Biblioteca("Biblioteca Municipal");

        // 2. Crear autores
        Autor a1 = new Autor("A1", "Gabriel Garcia Marquez", "Colombiana");
        Autor a2 = new Autor("A2", "Isabel Allende", "Chilena");
        Autor a3 = new Autor("A3", "J. K. Rowling", "Britanica");

        // 3. Agregar libros
        biblioteca.agregarLibro("L001", "Cien anios de soledad", 1967, a1);
        biblioteca.agregarLibro("L002", "El amor en los tiempos del colera", 1985, a1);
        biblioteca.agregarLibro("L003", "La casa de los espiritus", 1982, a2);
        biblioteca.agregarLibro("L004", "Harry Potter y la piedra filosofal", 1997, a3);
        biblioteca.agregarLibro("L005", "Harry Potter y la camara secreta", 1998, a3);

        // 4. Listar libros
        System.out.println("\n📚 LISTADO DE LIBROS:");
        biblioteca.listarLibros();

        // 5. Buscar libro por ISBN
        System.out.println("\n🔍 Buscar libro por ISBN (L003):");
        Libro buscado = biblioteca.buscarLibroPorIsbn("L003");
        if (buscado != null) buscado.mostrarInfo();

        // 6. Filtrar por año
        System.out.println("\n📅 Libros publicados en 1997:");
        biblioteca.filtrarLibrosPorAnio(1997);

        // 7. Eliminar un libro
        System.out.println("\n❌ Eliminar libro L002:");
        biblioteca.eliminarLibro("L002");
        biblioteca.listarLibros();

        // 8. Mostrar cantidad total
        System.out.println("\n📊 Total de libros: " + biblioteca.obtenerCantidadLibros());

        // 9. Mostrar autores disponibles
        System.out.println("\n👩‍💼 Autores disponibles:");
        biblioteca.mostrarAutoresDisponibles();
    }
}
