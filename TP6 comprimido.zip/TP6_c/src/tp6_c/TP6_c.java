/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp6_c;

public class TP6_c {

    public static void main(String[] args) {
        
   Universidad uni = new Universidad("Universidad Nacional de Cordoba");

        // 1. Crear profesores
        Profesor prof1 = new Profesor("P1", "Ana Gomez", "Matematica");
        Profesor prof2 = new Profesor("P2", "Luis Perez", "Informatica");
        Profesor prof3 = new Profesor("P3", "Maria Torres", "Fisica");

        // 2. Crear cursos
        Curso c1 = new Curso("C001", "Algebra I");
        Curso c2 = new Curso("C002", "Programacion II");
        Curso c3 = new Curso("C003", "Mecanica");
        Curso c4 = new Curso("C004", "Base de Datos");
        Curso c5 = new Curso("C005", "Calculo II");

        // 3. Agregar profesores y cursos a la universidad
        uni.agregarProfesor(prof1);
        uni.agregarProfesor(prof2);
        uni.agregarProfesor(prof3);

        uni.agregarCurso(c1);
        uni.agregarCurso(c2);
        uni.agregarCurso(c3);
        uni.agregarCurso(c4);
        uni.agregarCurso(c5);

        // 4. Asignar profesores a cursos
        uni.asignarProfesorACurso("C001", "P1");
        uni.asignarProfesorACurso("C002", "P2");
        uni.asignarProfesorACurso("C004", "P2");
        uni.asignarProfesorACurso("C003", "P3");
        uni.asignarProfesorACurso("C005", "P1");

        // 5. Listar
        System.out.println("\n📚 CURSOS Y PROFESORES:");
        uni.listarCursos();

        System.out.println("\n👩‍🏫 PROFESORES Y SUS CURSOS:");
        uni.listarProfesores();

        // 6. Cambiar profesor de un curso
        System.out.println("\n🔁 Cambiando profesor del curso C001...");
        c1.setProfesor(prof3);

        // 7. Eliminar un curso
        System.out.println("\n❌ Eliminando curso C004...");
        uni.eliminarCurso("C004");

        // 8. Eliminar un profesor
        System.out.println("\n❌ Eliminando profesor P2...");
        uni.eliminarProfesor("P2");

        // 9. Reporte final
        uni.mostrarReporteCursosPorProfesor();
    }
}