package EJ4;

public class Vaca extends Animal{ 
    @Override
    public void hacerSonido(){
        System.out.println("MUUUUUUUU!!");
    }
}
