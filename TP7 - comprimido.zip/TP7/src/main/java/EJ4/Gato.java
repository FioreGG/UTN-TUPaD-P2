package EJ4;

public class Gato extends Animal{ 

    @Override
    public void hacerSonido(){
        System.out.println("Miaaaaaau!!");
    }
}
