package EJ4;

public class Animal {
    public void hacerSonido(){      
    }
    public void describirAnaimal(){
        
    }
}
