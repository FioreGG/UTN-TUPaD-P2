package EJ4;

public class Perro extends Animal{ 

    @Override
    public void hacerSonido(){
        System.out.println("Guauuuuu Guauuuuu!!");
    }
}
