package EJ3;

public class EmpleadoPlanta extends Empleado{ // Extendemos de empleado
    
}
