package EJ3;

public class EmpleadoTemporal extends Empleado{ //Extendemos de empleado
    
}
