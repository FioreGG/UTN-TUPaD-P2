package EJ1;

public class Main {

    public static void main(String[] args) {

        Auto a = new Auto(5, "Ford", "Fiesta");
        
        a.mostrarInfo();
    }
    
}
