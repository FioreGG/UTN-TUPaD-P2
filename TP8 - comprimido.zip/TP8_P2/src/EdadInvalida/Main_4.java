/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package EdadInvalida;

import java.util.Scanner;

public class Main_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese edad: ");
        String lineaEdad = sc.nextLine();

        try {
            int edad = Integer.parseInt(lineaEdad); // puede lanzar NumberFormatException
            Persona p = new Persona(nombre, edad);  // puede lanzar EdadInvalidaException
            System.out.println("Persona creada: " + p);
        } catch (NumberFormatException e) {
            System.out.println("Error: la edad ingresada no es un numero valido.");
        } catch (EdadInvalidaException e) {
            System.out.println("Edad invalida capturada: " + e.getMessage());
        } finally {
            sc.close();
            System.out.println("Programa finalizado.");
        }
    }
}
