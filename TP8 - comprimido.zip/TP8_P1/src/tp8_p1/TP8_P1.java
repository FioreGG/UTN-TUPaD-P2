/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp8_p1;

public class TP8_P1 {

    public static void main(String[] args) {
     
        Cliente cliente = new Cliente("Maria");

        
        Pedido pedido = new Pedido(cliente);

        
        Producto p1 = new Producto("Libro", 1500);
        Producto p2 = new Producto("Mouse", 2500);
        Producto p3 = new Producto("Auriculares", 2000);

        
        pedido.agregarProducto(p1);
        pedido.agregarProducto(p2);
        pedido.agregarProducto(p3);

       
        double total = pedido.calcularTotal();
        System.out.println("Total del pedido: $" + total);

        
        pedido.cambiarEstado("Enviado");

        
        TarjetaCredito tarjeta = new TarjetaCredito();
        tarjeta.aplicarDescuento(10); // muestra mensaje de descuento
        tarjeta.procesarPago(total);  // muestra mensaje de pago
    }
}