/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Computadora;

public class Main {

    public static void main(String[] args) {
        
    Propietario propietario = new Propietario("Marcos Garcia", "30222111");
        Computadora computadora = new Computadora("Dell", "SN-2023-456", "Z790", "Intel");

        computadora.setPropietario(propietario);

        System.out.println(computadora);
        System.out.println("Propietario: " + computadora.getPropietario());
        System.out.println("Computadora del propietario: " + propietario.getComputadora());
    }
    
}
