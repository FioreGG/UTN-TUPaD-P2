/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Impuesto;

public class Main {

    public static void main(String[] args) {
        Contribuyente c = new Contribuyente("Pedro Sanchez", "20-12345678-9");
        Impuesto imp = new Impuesto(15000.0, c);

        Calculadora calc = new Calculadora();
        calc.calcular(imp);
    }
    }
    

