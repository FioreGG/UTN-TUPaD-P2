/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CitaMedica;

public class Main {

    public static void main(String[] args) {
        Paciente paciente = new Paciente("Carlos Aguirre", "OSDE");
        Profesional prof = new Profesional("Dra. Martinez", "Cardiologia");

        CitaMedica cita = new CitaMedica("2025-10-01", "10:00");
        cita.setPaciente(paciente);
        cita.setProfesional(prof);

        System.out.println("Cita medica para " + paciente + " con " + prof);
    }
    
}
