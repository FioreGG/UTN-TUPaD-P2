/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Documento;

public class Main {

    public static void main(String[] args) {
        Usuario usuario = new Usuario("Ana Rich", "ana@mail.com");
        FirmaDigital firma = new FirmaDigital("HASH123", "2025-09-26");
        firma.setUsuario(usuario);

        Documento doc = new Documento("Contrato", "Contenido del contrato...", firma);

        System.out.println("Documento: " + doc);
        System.out.println("Firmado por: " + usuario);
    }
    
}
