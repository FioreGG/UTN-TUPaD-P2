/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Celular;


public class Main {

    public static void main(String[] args) {
        Bateria bateria = new Bateria("Samsung-4000", 4000); // se crea la bateria
        
        Celular celular = new Celular ("1236541","Samsung 20","Modelo-20", bateria );
        
        Usuario usuario = new Usuario ("Alfio", "38152142");
        
        // se asocia usuario a celular <>
        celular.setUsuario(usuario);
        
        //Mostrar resultados
        System.out.println("Usuario: " +usuario);
        System.out.println("Celular del usuario:"+usuario.getCelular());
    }
    
}
