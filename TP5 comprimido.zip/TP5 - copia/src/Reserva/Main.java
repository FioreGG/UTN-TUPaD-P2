/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Reserva;

public class Main {

    public static void main(String[] args) {
      Cliente cliente = new Cliente ("Fiorella Garcia", "38161719");
      Mesa mesa = new Mesa (125,10);
      Reserva reserva = new Reserva ("2025-19-12","21:30hs", cliente, mesa);

        System.out.println(reserva);
      
    }
    
}
