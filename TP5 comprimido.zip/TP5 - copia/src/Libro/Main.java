/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Libro;

public class Main {

   
    public static void main(String[] args) {
       Autor autor = new Autor("Gabriel Perez","Mexicano");
       Editorial editorial = new Editorial("Editorial peruana", "Mitre 350");
       Libro libro = new Libro ("Muy buen libro y un mate","154-558922-12", autor, editorial);
       System.out.println("Autor del libro: "+ libro.getAutor());
       System.out.println("Editorial del libro: "+ libro.getEditorial());
       
    }
}
