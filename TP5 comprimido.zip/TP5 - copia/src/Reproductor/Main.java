/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Reproductor;

/**
 *
 * @author fiore
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Artista artista = new Artista("Shakira", "Pop");
        Cancion cancion = new Cancion("Hips Don't Lie", artista);

        Reproductor rep = new Reproductor();
        rep.reproducir(cancion);
    }
    
}
