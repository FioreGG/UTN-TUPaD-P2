/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package EditorVideo;

public class Main {

    public static void main(String[] args) {
        Proyecto proyecto = new Proyecto("Video Promocional", 120);
        EditorVideo editor = new EditorVideo();

        editor.exportar("MP4", proyecto);    }
    
}
