/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CuentaBancaria;

public class Main {

    public static void main(String[] args) {
        ClaveSeguridad clave = new ClaveSeguridad("ABC123", "2025-09-20");
        CuentaBancaria cuenta = new CuentaBancaria("1234567890123456789012", 15000.50, clave);

        Titular titular = new Titular("Rosa Diaz", "28999111");

        // Vínculo: podés llamar a cuenta.setTitular(titular) O titular.setCuenta(cuenta)
        cuenta.setTitular(titular);

        System.out.println(cuenta);
        System.out.println("Titular: " + cuenta.getTitular());
        System.out.println("Cuenta del titular: " + titular.getCuenta());
}}
