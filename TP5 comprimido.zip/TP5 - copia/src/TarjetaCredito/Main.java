/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TarjetaCredito;

public class Main {

    public static void main(String[] args) {
    Banco banco = new Banco ("Banco Nacion", "30-25856562-25");
    Cliente cliente = new Cliente("Pedro Ferrero", "3816171500");
    
    TarjetaDeCredito tarjeta = new TarjetaDeCredito ("12351561", "12/27", banco);
    tarjeta.setCliente(cliente);

    System.out.println(tarjeta);
    System.out.println("Cliente: " + tarjeta.getCliente());
    System.out.println("Banco: " + tarjeta.getBanco());
    System.out.println("Tarjeta del cliente: " + cliente.getTarjeta());
    }
    
}
