/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pasaporte;


public class Foto {
    private String formato;
    private String imagen;

    public Foto(String formato, String imagen) {
        this.formato = formato;
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Foto{" + "formato=" + formato + ", imagen=" + imagen + '}';
    }
    
    
}
