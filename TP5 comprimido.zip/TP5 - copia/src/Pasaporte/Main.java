/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pasaporte;


public class Main {

    public static void main(String[] args) {
        Titular titular = new Titular ("Juan de los Palotes", "32165244");
        Pasaporte pasaporte = new Pasaporte("AA25244", "2023-05-12", "foto.png","png");
        
        pasaporte.setTitular(titular);
        
        System.out.println(pasaporte);
        System.out.println("Titular: " +pasaporte.getTitular());
        System.out.println("Foto: "+pasaporte.getFoto());
    }
    
}
