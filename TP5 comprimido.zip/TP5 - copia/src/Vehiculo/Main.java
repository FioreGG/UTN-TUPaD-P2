/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Vehiculo;

public class Main {

    public static void main(String[] args) {
        Motor motor = new Motor("Nafta", "12345XYZ");
        Conductor conductor = new Conductor("Juan Garcia", "F-1234");
        Vehiculo vehiculo = new Vehiculo("AB123CD", "Ford");

        vehiculo.setMotor(motor);
        vehiculo.setConductor(conductor);

        System.out.println(vehiculo);
        System.out.println("Conductor maneja: " + conductor.getVehiculo().getModelo());
    }
    
}
